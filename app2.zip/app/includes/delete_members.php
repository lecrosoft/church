
<?php
include_once('../../connections/conn.php');

if (isset($_POST['userId'])) {
    $user_id = $_POST['userId'];

    $sql = "DELETE FROM `members` WHERE member_id = $user_id";
    $query_sql = mysqli_query($con, $sql);

    if ($query_sql) {
        echo "deleted";
    } else {
        die(mysqli_error($con));
    }
}
?>
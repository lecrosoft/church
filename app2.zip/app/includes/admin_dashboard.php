  <!-- ======= PRO BANNER COMES IN ================== -->
  <?php include('includes/pro_banner.php') ?>

  <!-- ======= PRO BANNER ENDS HERE ================== -->



  <!-- ================== PAGE HEADER COMES IN ==================== -->
  <?php include('includes/page_header.php') ?>
  <!-- ================== PAGE HEADER ENDS HERE ==================== -->


  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM STARTS HERE ============ -->
  <?php include('includes/first_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM ENDSHERE ============ -->



  <!-- =================== SECOND SECTION TO DISPLAY INCOME AND EXPENSES AND CHARTS AND MARITAL STATUS  STARTS HERE ============ -->
  <?php include('includes/second_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM ENDSHERE ============ -->

  <!-- =================== SECOND SECTION TO DISPLAY MEMBERS,USERS,DEPARTMENTS  STARTS HERE ============ -->
  <?php include('includes/members_analytics_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM ENDSHERE ============ -->


  <!-- =================== SECOND SECTION TO DISPLAY BIRTRHDAY  STARTS HERE ============ -->
  <?php include('includes/birthday_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY BIRTHDAY ENDSHERE ============ -->


  <!-- =================== SECOND SECTION TO DISPLAY BIRTRHDAY  STARTS HERE ============ -->
  <?php include('includes/firsttimmer_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY BIRTHDAY ENDSHERE ============ -->
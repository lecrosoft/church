<?php
include('../connections/conn.php');

if (isset($_POST['memberID'])) {

    $memberID = $_POST['memberID'];

    $departmentClickedID = $_POST['departmentClickedID'];
    $lecrosoft = "SELECT * FROM members WHERE member_id = $memberID";
    $query_lecrosoft = mysqli_query($con, $lecrosoft);

    $row = mysqli_fetch_assoc($query_lecrosoft);
    extract($row);
}
?>


<div class="modal-header bg-gradient-primary">

    <h5 class="modal-title">You are about to record payment for <span class="text-white"><?php echo $first_name . " " . $last_name ?></span></h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th>Payment categories</th>
            </tr>
        </thead>
        <tbody>

            <?php
            $sql = "SELECT * FROM `department_income_category` WHERE department_id = $departmentClickedID";
            $query_sql = mysqli_query($con, $sql);



            while ($row = mysqli_fetch_assoc($query_sql)) {
                extract($row);


                echo "<tr>
                <td><a href='#'>$title</a></td>

            </tr>";
            }

            ?>


        </tbody>
    </table>
    </table>
</div>


<?php
// if (isset($_POST['update'])) {
//     $fam_id = $_POST['update'];

//     $lecrosoft = "UPDATE `family` SET `family_name`='$family_name',`family_leader`='$family_leader',`family_quantity`=$family_quantity,`family_contact`='$family_contact',`address`='$address',`status`='$status',`join_date`='$join_date' WHERE `family_id` = $fam_id";
//     $query_lecrosoft = mysqli_query($con, $lecrosoft);
//     if (!$query_lecrosoft) {
//         echo '<script type=text/javascript>location = "family.php"</script>';
//     } else {
//         die("QUERY ERROR" . mysqli_error($con));
//     }
// }
?>
<!-- <script src="./includes/script.js"></script> -->
<script>
    $(document).ready(function() {
        $('.add-payment_button').click(function(e) {
            e.preventDefault();

            let member_id = $('#member_id').val();

            let created_by = $('#created_by').val();
            let logged_in_member_lname = $('#logged_in_member_lname').val();

            let member_fname = $('#member_fname').val();
            let member_lname = $('#member_lname').val();
            let depart_id = $('#depart_id').val();
            let amount = $('#amount').val();
            let category = $('#category').val();
            let payment_method = $('#payment_method').val();
            let payment_date = $('#payment_date').val();
            let note = $('#note').val();

            $.ajax({
                url: "fetch_department_payment_form.php",
                method: "POST",
                data: {
                    depart_member_id: member_id,
                    depart_id: depart_id,
                    amount: amount,
                    category: category,
                    payment_method: payment_method,
                    payment_date: payment_date,
                    note: note,
                    member_lname: member_lname,
                    member_fname: member_fname

                },

                success: function(data) {
                    location = window.location.href;
                }
            })



        })
    })
</script>
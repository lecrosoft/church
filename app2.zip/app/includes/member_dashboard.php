  <!-- ======= PRO BANNER COMES IN ================== -->
  <?php include('includes/member_pro_banner.php') ?>

  <!-- ======= PRO BANNER ENDS HERE ================== -->



  <!-- ================== PAGE HEADER COMES IN ==================== -->
  <?php include('includes/page_header.php') ?>
  <!-- ================== PAGE HEADER ENDS HERE ==================== -->


  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM STARTS HERE ============ -->
  <?php include('includes/member_first_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY INCOME AND EXPENSES AND BALANCE SUM ENDSHERE ============ -->








  <!-- =================== SECOND SECTION TO DISPLAY BIRTRHDAY  STARTS HERE ============ -->
  <?php include('includes/member_birthday_section.php') ?>
  <!-- =================== FIRST SECTION TO DISPLAY BIRTHDAY ENDSHERE ============ -->